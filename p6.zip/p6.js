/*
    CIT 281 Project 6
    Name: Rohan Kumar
*/
class Shape     //shape class
{
    constructor (sides = [])
    {
        this.sides = sides;
    }
    perimeter = () => {return this.sides.reduce(function(a, b) {return a + b}, 0);} //perimeter function
}
/*  test code
    console.log(new Shape([5, 10]).perimeter());  // 15
    console.log(new Shape([1, 2, 3, 4, 5]).perimeter()); // 15
    console.log(new Shape().perimeter()); // 0
*/
class Rectangle extends Shape   //rectangle class
{
    constructor(length, width, sides = [length, width, length, width])
    {
        super(sides);
        this.length = length;
        this.width = width;
    }
    area()
    {
        return this.length * this.width; //area function for rectangle
    }
}
/*  test code
    console.log(new Rectangle(4, 4).perimeter());  // 16
    console.log(new Rectangle(4, 4).area());  // 16
    console.log(new Rectangle(5, 5).perimeter()); // 20
    console.log(new Rectangle(5, 5).area()); // 25
    console.log(new Rectangle().perimeter()); // 0
    console.log(new Rectangle().area()); // 0
*/
class Triangle extends Shape    //triangle class
{
    constructor(sideA, sideB, sideC, sides = [sideA, sideB, sideC], s)
    {
        super(sides);
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
        this.s = s;
    }
    area() //area function for triangle (Heron's formula)
    {
        this.s = Math.sqrt
        (
            (this.sideA + this.sideB + this.sideC) / 2
            *
            (((this.sideA + this.sideB + this.sideC) / 2) - this.sideA)
            *
            (((this.sideA + this.sideB + this.sideC) / 2) - this.sideB)
            *
            (((this.sideA + this.sideB + this.sideC) / 2) - this.sideC)
        )
        return this.s;
    }
}
/*  test code
    console.log(new Triangle(3, 4, 5).perimeter());  // 12
    console.log(new Triangle(3, 4, 5).area());  // 6
    console.log(new Triangle().perimeter()); // 0
    console.log(new Triangle().area()); // 0
*/
//array of sides
const data = [[3, 4], [5, 5], [3, 4, 5], [1], [0]];
//destructure array into variables
let [arr1, arr2, arr3, arr4, arr5] = data;
let [arr1A, arr1B] = arr1;  //[3,4]
let [arr2A, arr2B] = arr2;  //[5,5]
let [arr3A, arr3B, arr3C] = arr3;   //[3,4,5]
//print output
console.log
(
    "Rectangle with sides " + arr1A + ", " + arr1B + " has perimeter of "
    + new Rectangle(arr1A, arr1B).perimeter() + " and area of "
    + new Rectangle(arr1A, arr1B).area() + "."
    
);
console.log
(
    "Square with sides " + arr2A + ", " + arr2B + " has perimeter of "
    + new Rectangle(arr2A, arr2B).perimeter() + " and area of "
    + new Rectangle(arr2A, arr2B).area() + "."
);
console.log
(
    "Triangle with sides " + arr3A + ", " + arr3B + ", " + arr3C + " has perimeter of "
    + new Triangle(arr3A, arr3B, arr3C).perimeter() + " and area of "
    + new Triangle(arr3A, arr3B, arr3C).area() + "."
);
console.log("Shape with " + arr4 + " side is unsupported.");
console.log("Shape with " + arr5 + " sides is unsupported.");